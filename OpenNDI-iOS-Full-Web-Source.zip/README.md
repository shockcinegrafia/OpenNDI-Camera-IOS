# OpenNDI iOS Full Web Integration - fonte extraída

Interface COMPLETA extraída de `WebStreamServer.kt` (`serveHtml()`), preservada no arquivo `ios/OpenNDILegacy/index_full.html`. A versão Lite também foi incluída como opção secundária.

ATENÇÃO: Este pacote é de fontes, não um IPA. O HTML completo utiliza rotas do Android, que ainda precisam ser implementadas no servidor Objective-C iOS; a simples inclusão do HTML não torna seus controles funcionais. Não substituir a versão estável 0.1.1 até validar vídeo e controles.

## Integração
1. Adicionar `index_full.html` e `index_lite.html` aos recursos do Makefile Theos.
2. Servir `index_full.html` em `/` e `/index.html`, `index_lite.html` em `/lite` e `/index_lite.html`.
3. Implementar e validar `/state.json`, `/action/*`, `/stream`, `/stream_sd` no servidor iOS antes de habilitar controles.
4. Preservar `/snapshot.jpg` e `/api/status` como fallback.
5. Compilar com o workflow macOS autorizado após subir a implementação ao repositório.

Extração verificada: o HTML completo está incorporado no Kotlin, não em assets/web.
