# OpenNDI Camera — Contrato de interface Android / iOS Legacy

Origem da interface: `app/src/main/assets/web/index_lite.html` do pacote Android `openndi-camera-v1.1.0-ndi-clean.zip`. Copiada **sem modificações** para `web/index_lite.html`.

## Regra de produto

A interface Web Lite do Android é a fonte de verdade compartilhada, já testada pelo usuário no Safari do iPad mini 1. Não reescrever a UI. Toda nova funcionalidade Android deve ser avaliada para iOS 9 ARMv7; publicar matriz de capacidades por versão. Preservar IPA 0.1.1 como fallback estável.

## Diagnóstico de integração (código-fonte Android)

- A UI Web Lite chama `GET /state.json` e `GET /action?type=<comando>&value=<valor>` via XHR ES5.
- Vídeo é carregado de `/stream_sd` ou `/stream`; existe fallback de `/snapshot.jpg`.
- O HTML tem seleção de host remoto persistida em `localStorage`, que deve ser respeitada.
- O iOS 0.1.1 fornece `/snapshot.jpg`, `/api/status` e `/` mas ainda **não** fornece `/state.json`, `/action` ou `/stream_sd`. Logo, simplesmente copiar HTML para o IPA não habilita os controles.
- O Android tem NDI nativo ARM64; essa biblioteca Android não é utilizável diretamente no iOS ARMv7. NDI iOS permanece em investigação separada.

## Contrato mínimo a implementar no servidor iOS

| Rota | Tipo | Resultado exigido |
|---|---|---|
| `/index_lite.html` | GET | HTML original, Content-Type `text/html; charset=utf-8` |
| `/state.json` | GET | JSON com `isTransmitting`, `batteryLevel`, `isMicEnabled` e demais campos compatíveis que sejam reais |
| `/action?type=switch_camera` | GET | Alternar câmera se suportado, ou JSON de erro explícito |
| `/action?type=set_zoom&value=...` | GET | Aplicar zoom suportado ou erro explícito |
| `/action?type=tap_focus&value=...` | GET | Ajustar foco se suportado ou erro explícito |
| `/action?type=toggle_torch` | GET | Alternar flash se suportado ou erro explícito |
| `/action?type=start_record` e `stop_record` | GET | Apenas após implementação real; nunca anunciar gravação fictícia |
| `/stream_sd` e `/stream` | GET | MJPEG `multipart/x-mixed-replace; boundary=frame` com backpressure e limpeza de cliente |
| `/snapshot.jpg` | GET | JPEG atualizado, preservando funcionamento da v0.1.1 |
| `/api/capabilities` | GET | Proposta de extensão: recursos e limites reais por dispositivo |

### Atenção de segurança

Servidor HTTP local expõe comandos para qualquer cliente na mesma rede. Antes de ativar gravação, flash ou controle remoto, adicionar autorização por token ou pareamento local e limites de requisições. Não expor servidor na Internet.

## Etapas e critérios de aceitação

1. Integrar HTML original como recurso embarcado e servi-lo sem alterar CSS/JS. Confirmar visual no Safari iOS 9.
2. Implementar `/state.json` e ações básicas usando AVFoundation; retorno de erro para recursos não implementados. Verificar que cada botão altera o estado real.
3. Implementar MJPEG preservando snapshot e teste regressivo de 10 FPS no Android Chrome.
4. Documentar contrato HTTP compartilhado e adicionar testes de respostas JSON/ações, incluindo estados não suportados.
5. Captura de áudio e transporte compatível com OBS, validando sincronismo; MJPEG sozinho não leva áudio.

**Não executar build macOS pago sem autorização explícita do usuário.**
